var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('mateus show de bola ');
});

router.get('/exercicios', function(req, res, next) {
  res.send('1');
});

router.get('/provas', function(req, res, next) {
  res.send('1');
});

router.get('/notas', function(req, res, next) {
  res.send('10,0    5,0');
});

module.exports = router;
